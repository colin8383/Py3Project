"""为应用程序users定义URL模式"""

from django.conf.urls import url
from django.contrib.auth.views import LoginView

from . import views

urlpatterns = [
    # 登录页面
    # https://blog.csdn.net/steventian72/article/details/85225631
    # url(r'^login/$', login, {'template_name': 'users/login.html'},
    #     name='login'),

    # 登录界面
    url(r'^login/$', LoginView.as_view(template_name='users/login.html'),
        name='login'),
    # 注销
    url(r'^logout/$', views.logout_view, name='logout'),
    # 注册页面
    url(r'^register/$', views.register, name='register'),
]