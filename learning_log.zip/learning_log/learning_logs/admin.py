from django.contrib import admin

# Register your models here.

# 在Local中运行python manage.py runserver来启动Django服务
# 在默认网页中http://127.0.0.1:8000/后增加admin/
# 用之前创建的超级管理员ll_admin登录
# 可以看到Groups、Users和自己增加的Topics

# 导入我们要注册的模型
from learning_logs.models import Topic, Entry
# from django.contrib import admin


# class BookInfoAdmin(admin.ModelAdmin):
#     list_display = ['', '']
#
#
# class HeroInfoAdmin(admin.ModelAdmin):
#     list_display = ['', '']

# 让Django通过管理网站管理我们的模型
admin.site.register(Topic)
admin.site.register(Entry)


