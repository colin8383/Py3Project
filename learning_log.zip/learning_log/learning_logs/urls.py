"""定义learning_logs的URL模型"""
from django.conf.urls import url
# 其中的句点让Python从当前的urls.py模块所在的文件夹中导入视图
from . import views

urlpatterns = [
    # 主页
    # 实际的URL模式是一个对函数url()的调用，这个函数接受3个实参
    # 第一个：是正则表达式(r'^&')，其中的r让Python将接下来的字符串视为原始字符串，
    # 而引号告诉Python正则表达式始于和终于何处。脱字符(^)让Python查看字符串的开头，
    # 而美元符号让Python查看字符串的末尾。总体而言，这个正则表达式让Python查找开头
    # 和结尾之间没有任何东西的URL。
    # 第二个：指定了要调用的视图函数。请求的URL与前述正则表达式匹配时，调用views.index
    # 第三个：将这个URL模式的名称指定为index，让我们能够在代码的其他地方引用它

    # 显示主页
    url(r'^$', views.index, name='index'),

    # 显示所有的主题
    url(r'^topics/$', views.topics, name='topics'),

    # 显示一个主题的明细
    url(r'^topics/(?P<topic_id>\d+)/$', views.topic, name='topic'),

    # 用于添加新主题的网页
    url(r'new_topic/$', views.new_topic, name='new_topic'),

    # 用于添加新条目的页面
    url(r'new_entry/(?P<topic_id>\d+)/$', views.new_entry, name='new_entry'),

    # 用于编辑条目的界面
    url(r'edit_entry/(?P<entry_id>\d+)/$', views.edit_entry, name='edit_entry'),
]
